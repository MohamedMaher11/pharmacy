package com.example.hamo_pharmacy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
